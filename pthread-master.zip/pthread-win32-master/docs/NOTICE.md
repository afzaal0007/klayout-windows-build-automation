pthreads-win32 / pthreads4w - POSIX threads for Windows
Copyright 1998 John E. Bossom
Copyright(C) 1999-2021 pthreads-win32 / pthreads4w contributors

This product includes software developed through the colaborative
effort of several individuals, each of whom is listed in the file
CONTRIBUTORS included with this software.