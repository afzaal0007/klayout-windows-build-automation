WinCE port
----------
(See the file WinCE-PORT for a detailed explanation.)

Make sure you define "WINCE" amongst your compiler flags (eg. -DWINCE).
The config.h file will define all the necessary defines for you.
